﻿using Fruityvice.Models;
using Fruityvice.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Threading.Tasks;


namespace Fruityvice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FruitController : ControllerBase
    {

        private readonly IFruitService _fruitService;
        public FruitController(IFruitService fruitService)
        {
            _fruitService = fruitService;
        }

        [HttpGet]
        [Route("GetAll")]
        public async Task<ActionResult> GetAll()
        {
            var response = await _fruitService.GetALL();

            return Ok(response);
        }

        [HttpPost]
        [Route("Get")]
        public async Task<IActionResult> GetFruit([FromBody] SearchParamer searchParamer)
        {
            var response = await _fruitService.GetByFamily(searchParamer.Family);

            return Ok(response);
        }
    }
}
