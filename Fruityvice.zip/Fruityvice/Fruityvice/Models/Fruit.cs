﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fruityvice.Models
{
    public class Fruit
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public string Family { get; set; }

        public string Order { get; set; }
        public string Genus { get; set; }


        public Nutritions Nutritions { get; set; } 
    }

    public class Nutritions
    {
        public int Calories { get; set; }
        public decimal Fat { get; set; }
        public decimal Sugar { get; set; }
        public decimal Carbohydrates { get; set; }
        public decimal Protein { get; set; }
    }

    public class SearchParamer
    {
        public string Family { get; set; }
    }
}
