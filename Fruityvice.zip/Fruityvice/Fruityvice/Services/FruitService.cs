﻿using Fruityvice.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Fruityvice.Services
{
    public class FruitService : IFruitService
    {
        private readonly HttpClient _httpClient;
        public FruitService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        public async Task<IEnumerable<Fruit>> GetALL()
        {
            try
            {
                var response = await _httpClient.GetAsync("https://www.fruityvice.com/api/fruit/all");

                var content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<List<Fruit>>(content);
                return result;
            }
            catch (Exception ex)
            {
                return new List<Fruit>();
            }
        }

        public async Task<IEnumerable<Fruit>> GetByFamily(string fruitFamily)
        {
            try
            {
                var response = await _httpClient.GetAsync("https://www.fruityvice.com/api/fruit/family/"+fruitFamily);

                var content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<List<Fruit>>(content);
                return result;
            }
            catch (Exception ex)
            {
                return new List<Fruit>();
            }
        }
    }
}
