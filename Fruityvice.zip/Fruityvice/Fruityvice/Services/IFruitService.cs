﻿using Fruityvice.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Fruityvice.Services
{
    public interface IFruitService
    {
        Task<IEnumerable<Fruit>> GetALL();
        Task<IEnumerable<Fruit>> GetByFamily(string family);
    }
}
