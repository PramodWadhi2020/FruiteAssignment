﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using Fruityvice.Services;
using Moq;
using Fruityvice.Models;
using System.Threading.Tasks;
using System.Net.Http;
using System.Web.Http.Results;

namespace FruitService.Test.Services
{
    public class FruitServiceTest
    {
        private Fruityvice.Services.FruitService _fruitService;
        private Mock<HttpClient> mockHttpCLient;
        [SetUp]
        public void Setup()

        {
            mockHttpCLient = new Mock<HttpClient>();
            _fruitService = new Fruityvice.Services.FruitService(mockHttpCLient.Object);
        }

        [Test]
        public void WhenGetALll_ThenAllRecordShouldBeGet()
        {
            // Arrrage
            var nurition = new Nutritions()
            {
                Calories = 43,
                Fat = 0.2M,
                Sugar = 8.2M,
                Carbohydrates = 8.3M,
                Protein = 8.3M
            };
            IEnumerable<Fruit> fruits = new List<Fruit>()
            {
              new Fruit() {
                  Name="Orange", Id=2, Family="Rutaceae", Order="Sapindales", Genus="Citrus", Nutritions = nurition
              }
            };

            // Act
            var result = _fruitService.GetALL();

            int total = 0;
            foreach (var item in result.Result)
            {
                total++;
            }
            // Assert

            Assert.AreEqual(total, 40); ;
        }

        [Test]
        public void When_GetByFamily_Expect_FruitFamilyByFilter()
        {
            // Arrrage
            var nurition = new Nutritions()
            {
                Calories = 43,
                Fat = 0.2M,
                Sugar = 8.2M,
                Carbohydrates = 8.3M,
                Protein = 8.3M
            };
            IEnumerable<Fruit> fruits = new List<Fruit>()
            {
              new Fruit() {
                  Name="Orange", Id=2, Family="Rutaceae", Order="Sapindales", Genus="Citrus", Nutritions = nurition
              }
            };

            // Act
            var result = _fruitService.GetByFamily("Rutaceae");
            int total = 0;
            foreach (var item in result.Result)
            {
                total++;
            }
            // Assert

            Assert.AreEqual(total, 4); ;
        }
    }
}
