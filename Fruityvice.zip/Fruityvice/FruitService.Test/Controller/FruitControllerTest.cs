﻿using Fruityvice.Controllers;
using Fruityvice.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Results;

namespace FruitService.Test.Controller
{
    public class FruitControllerTest
    {
        private Mock<Fruityvice.Services.FruitService> _fruitService;
        //private Mock<HttpClient> mockHttpCLient;

        [SetUp]
        public void Setup()

        {
            //mockHttpCLient = new Mock<HttpClient>();
            _fruitService = new Mock<Fruityvice.Services.FruitService>(); // (mockHttpCLient.Object);
        }

        
    }
}
